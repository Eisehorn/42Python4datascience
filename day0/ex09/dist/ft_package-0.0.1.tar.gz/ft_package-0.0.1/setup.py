from setuptools import setup

setup(
    name="ft_package",
    version="0.0.1",
    description="A sample test package",
    url="https://github.com/fgiulian/ft_package",
    author="Literally my father: eagle!",
    author_email="dehpeffò@vedrai.pontedera",
    license="MIT",
    classifiers=[
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
    ],
    entry_points={
        # Define entry points here if your package provides any
    },
)

